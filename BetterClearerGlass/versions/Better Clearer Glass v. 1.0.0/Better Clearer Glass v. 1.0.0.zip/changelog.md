- initial release
- separated clear glass textures from energy shaders into its own pack, so it can be activated
  individually.