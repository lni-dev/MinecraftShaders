### 2.0.4
- fixed aplha-cut-off on armor 
  - minecraft: `rendertype_armor_cutout_no_cull.json`
- fixed inventory light on items (changed in 24w05b)
- updated pack version
- reduced night grey scale
- added `NIGHT_GREY_SCALE_PERCENTAGE` setting
- updated to Sodium 0.5.8